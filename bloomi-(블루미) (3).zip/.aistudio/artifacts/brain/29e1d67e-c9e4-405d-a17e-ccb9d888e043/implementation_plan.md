# BLOOMI (블루미) — 스마트 꽃잎 호흡 & AI 웰니스 키링 웹 플랫폼

첨부된 HTML 프로토타입의 감성적인 디자인과 인터랙티브 호흡 하드웨어 시뮬레이터를 React + TypeScript 기반의 풀스택 웹 애플리케이션으로 충실히 구현합니다. 서버 사이드 Gemini AI 프록시를 통해 API 키 노출 없이 안전한 AI 마음 상담 및 호흡 루틴 처방을 제공하며, 사용자의 호흡 및 감정 기록을 브라우저 `localStorage`에 영구 저장합니다.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> **Phase 1에서 확정된 핵심 설계 방향**
> - **보안 중심 Gemini AI 연동**: 사용자가 직접 관리하는 `GEMINI_API_KEY`가 클라이언트 번들이나 브라우저 네트워크에 절대 노출되지 않도록 Express 백엔드 프록시(`/api/ai/care`)를 통해서만 `@google/genai` (`gemini-4-hydrogen`)를 호출합니다. 키는 AI Studio의 **Settings > Secrets** 패널에서 안전하게 설정할 수 있습니다.
> - **세션 및 감정 기록 영구 저장**: 호흡 완료 기록, 심박 변화(`BPM`), 주관적 감정 체크인 데이터를 브라우저 `localStorage`에 자동 저장하여 페이지를 새로고침해도 누적 통계와 기록이 유지됩니다.
> - **HTML 디자인 및 기능 1:1 충실 구현**: 크림(`#FAF8F5`)·블러쉬(`#F4A6B8`)·세이지(`#8FB996`)·라벤더(`#B8B5E8`) 컬러 팔레트, 4개 핵심 탭, 5꽃잎 SVG 키링 & 7-픽셀 NeoPixel LED 링, D8 택트 스위치, Web Serial(XIAO ESP32-C3) 연동, Tone.js 차임 안내를 그대로 React 아키텍처로 구현합니다.

---

### 1. Overview & Core Concept

- **What It Does**: 스마트폰 화면에 의존하지 않는 소형 꽃잎 호흡 키링 디바이스(BLOOMI)의 디지털 트윈 스튜디오, Gemini AI 기반 감정 상담 및 루틴 처방, 생체신호(PPG 심박수·GSR 긴장도) 실시간 시각화 및 주간 웰니스 리포트를 단일 웹 워크스페이스에서 제공합니다.
- **Target Audience / Persona**: 시험·면접을 앞둔 수험생, 업무 스트레스에 노출된 직장인, 일상 속 즉각적인 심호흡과 심리적 안정이 필요한 현대인 및 BLOOMI 하드웨어 프로토타입 테스트 팀.
- **Key Value**: 원터치 호흡 페이서(4-7-8 / 4-4-4-4 박스 / 5-5 공명)로 즉각적인 생체 안정을 유도하고, AI 대화에서 도출된 맞춤 루틴을 단 한 번의 클릭으로 키링 시뮬레이터에 즉시 적용합니다.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **실시간 호흡 스튜디오**: 상단에서 XIAO ESP32-C3 USB(Web Serial) 연결 또는 시뮬레이션 시나리오(긴장/일상/이완)를 선택하고, 꽃잎 커버 색상(벚꽃 블러쉬·라벤더 미스트·세이지 민트·문라이트 펄)을 커스터마이징합니다. 측면 `D8 스위치` 또는 `호흡 가이드 시작` 버튼을 누르면 꽃잎 개폐 애니메이션, 7개 LED 색상, Tone.js 사운드 차임이 호흡 박자에 맞춰 동기화됩니다.
  2. **AI 마음 케어**: 고민을 자유 입력하거나 상황별 칩(면접·업무·인간관계)을 선택하면 백엔드 Gemini AI가 공감 메시지와 함께 최적의 호흡 루틴 카드를 처방합니다. 카드의 `키링으로 바로 실행하기` 버튼을 클릭하면 스튜디오 탭으로 전환되어 즉시 해당 호흡이 시작됩니다.
  3. **웰니스 기록 & 리포트**: 호흡 완료 후 마음 상태를 체크인하면 `localStorage`에 저장되고, 상단 KPI(누적 연습 횟수, 평균 BPM 안정 효과 등)와 주간 막대 차트, 최근 기록 목록이 실시간으로 갱신됩니다.
  4. **기획 & 하드웨어 구조**: Physical·AI·Data 3대 핵심 가치, 5가지 설계 원칙, XIAO ESP32-C3 핀 맵(D0, A1, A2, D8) 및 브레드보드 배선 다이어그램을 확인할 수 있습니다.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: 따뜻하고 촉각적인 웰니스 하드웨어 스튜디오. 날카로운 테크 대시보드 대신 반투명 글래스 카드와 부드러운 유기적 곡선으로 심리적 안정감을 전달합니다.
  - *Color Palette & Mood*: Warm Cream(`#FAF8F5`)을 60% 주 배경으로 사용하고, 순백색 글래스 서피스(30%) 위에 Blush Pink(`#F4A6B8`), Sage Mint(`#8FB996`), Lavender Mist(`#B8B5E8`), Charcoal(`#2C2A2E`)을 10% 포인트 컬러로 배치합니다.
  - *Typography & Hierarchy*: 한국어 가독성이 뛰어난 `Noto Sans KR`과 숫자 정렬(`tabular-nums`)을 결합하여 심박(BPM)·긴장도(GSR)·타이머 수치의 흔들림을 방지합니다.
  - *Component Styling & Layout*: 데스크톱 12컬럼 그리드(좌측 5컬럼 하드웨어 시뮬레이터, 우측 7컬럼 루틴 선택 및 생체 텔레메트리)와 모바일 가로 스크롤 탭 네비게이션을 제공합니다.

- **Interactive Feedback & Motion**:
  - 호흡 단계(들이마시기·멈춤·내쉬기)에 따라 꽃잎 SVG 스케일 및 주변 글로우 헤일로가 CSS `cubic-bezier` 트랜지션으로 부드럽게 전환됩니다.
  - 토스트 알림으로 커버 변경, 루틴 선택, 세션 저장, USB 연결/해제 상태를 즉시 안내하며, AI 응답 대기 시 로딩 인디케이터와 오류 시 명확한 안내 메시지를 표시합니다.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: AI 마음 케어의 서버 사이드 프록시 아키텍처**
  - *Chosen Approach*: Express 서버(`tsx`)가 Vite 미들웨어를 호스팅하며 `/api/ai/care` POST 엔드포인트를 통해 `@google/genai` SDK(`gemini-4-hydrogen`, Structured JSON `responseSchema`)를 호출합니다.
  - *Why*: `GEMINI_API_KEY`가 클라이언트 번들에 포함되거나 브라우저에 노출되는 문제를 원천 차단하며, JSON 스키마 강제를 통해 AI 응답이 항상 `[공감 메시지 + 추천 루틴 키(478/box/calm) + 추천 이유]` 구조로 안전하게 반환됩니다.
  - *Alternatives Considered*: 클라이언트 직접 호출 방식은 API 키 유출 위험이 있으므로 배제하였고, 정적 키워드 매칭만 사용하는 방식은 다양한 고민에 유연하게 대응하기 어려워 Gemini AI 연동으로 고도화했습니다.

- **Decision 2: `localStorage` 기반 클라이언트 영구 저장**
  - *Chosen Approach*: `bloomi_wellness_logs_v1` 키를 사용하여 호흡 기록 및 감정 체크인을 JSON 형태로 직렬화하여 `localStorage`에 저장·복원합니다.
  - *Why*: 별도의 로그인 절차나 외부 DB 프로비저닝 없이도 개인 기기에서 즉시 기록이 보존되며, 오프라인 및 시뮬레이션 환경에서도 지연 없이 리포트를 갱신할 수 있습니다.
  - *Alternatives Considered*: 인메모리 상태는 새로고침 시 데이터가 소실되는 한계가 있어 `localStorage` 영구 저장으로 개선했습니다.

- **Decision 3: Tone.js npm 패키지 번들링 및 Canvas 60fps 렌더링**
  - *Chosen Approach*: CDN 스크립트 대신 `tone` 패키지를 설치하여 React 훅으로 사운드 합성을 관리하고, PPG 심박 파형·GSR 추이·주간 차트는 `requestAnimationFrame` 기반 Canvas API로 정밀하게 렌더링합니다.
  - *Why*: 외부 CDN 의존성을 제거해 안정적인 빌드 및 오프라인 동작을 보장합니다.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:
```text
┌────────────────────────────────────────────────────────────────────┐
│                    Browser (React SPA + Vite)                      │
│                                                                    │
│  ┌──────────────┐   ┌───────────────────┐   ┌──────────────────┐   │
│  │  Top Header  │   │  Studio Workspace │   │  AI Care Chat    │   │
│  │  & WebSerial ├──▶│  - Flower SVG     │◀──┤  - Preset Chips  │   │
│  │  Connector   │   │  - Tone.js Chime  │   │  - Routine Card  │   │
│  └──────┬───────┘   │  - PPG/GSR Canvas │   └────────┬─────────┘   │
│         │           └─────────┬─────────┘            │             │
│         │                     ▼                      │ POST JSON   │
│         │           ┌───────────────────┐            │ /api/ai/care│
│         │           │ Wellness Report   │            ▼             │
│         │           │ & localStorage    │   ┌──────────────────┐   │
│         │           └───────────────────┘   │  Express Server  │   │
└─────────┼───────────────────────────────────│  (Port 3000)     │───┘
          │ Web Serial (115200 baud)          │  - Input Check   │
          ▼                                   │  - @google/genai │
   ┌─────────────┐                            │  - ENV Key Only  │
   │ XIAO ESP32  │                            └────────┬─────────┘
   │ D0/A1/A2/D8 │                                     │
   └─────────────┘                                     ▼
                                              ┌──────────────────┐
                                              │  Gemini 4 API    │
                                              │  (Hydrogen)      │
                                              └──────────────────┘
```

- **Data Model & State**:
  - **BiometricTelemetry**: `{ bpm: number, gsr: number, gsrRaw: number, hrHistory: number[], gsrHistory: number[], isSerialConnected: boolean, simScenario: 'tense' | 'normal' | 'relaxed' }`
  - **BreathingState**: `{ isBreathing: boolean, routineKey: '478' | 'box' | 'calm', cycleCount: number, phaseIndex: number, phaseElapsed: number, petalTheme: 'blush' | 'lavender' | 'sage' | 'pearl' }`
  - **WellnessSessionLog**: `{ id: string, time: string, routine: string, routineKey: '478' | 'box' | 'calm', bpmBefore: number, bpmAfter: number, mood: string }` (`localStorage` 동기화)
  - **AiCareMessage**: `{ id: string, sender: 'user' | 'ai', text: string, prescription?: { routineKey: '478' | 'box' | 'calm', routineTitle: string, reason: string } }`

- **Interactive Component & State Mapping**:
  - **Web Serial 컨트롤러**: 브라우저 `navigator.serial` 포트를 115200bps로 연결해 `BPM:xx,GSR:xx,BTN:1` 스트림을 파싱하고 `BTN:1` 수신 시 `D8 스위치` 핸들러를 트리거합니다.
  - **호흡 페이서 엔진**: `useEffect` 타이머가 1초 단위로 단계 전환을 계산하고, 꽃잎 SVG 스케일, 7개 NeoPixel LED 색상, Tone.js 화음을 동기화합니다. 4사이클 완료 시 자동으로 이완 시나리오로 전환합니다.
  - **AI 마음 케어 파이프라인**: 사용자 입력을 `/api/ai/care`로 전송하여 로딩 상태, 구조화된 추천 루틴 카드 렌더링, 오류 안내(네트워크 또는 API 키 미설정 안내)를 처리합니다.

- **Security & Privacy Safeguards**:
  - **API 키 서버 격리**: `GEMINI_API_KEY`는 오직 서버(`process.env.GEMINI_API_KEY`)에서만 읽으며, 브라우저 UI에 키 입력 폼을 생성하거나 클라이언트 번들에 키를 포함하지 않습니다.
  - **입력 검증 및 안전한 렌더링**: 백엔드 엔드포인트에서 요청 본문 타입·길이(최대 1,000자)를 검증하고, 프론트엔드는 React의 기본 텍스트 바인딩을 사용해 스크립트 삽입을 원천 차단합니다.
  - **오류 처리 투명성**: API 키 누락·할당량 초과·네트워크 오류 시 가짜 AI 응답으로 덮지 않고 사용자에게 명확한 상태 안내와 설정(Secrets) 확인 가이드를 반환합니다.
