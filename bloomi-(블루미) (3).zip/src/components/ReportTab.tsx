import {useMemo, useState} from 'react';
import {
  Activity,
  BarChart3,
  CalendarDays,
  HeartPulse,
  Sparkles,
  Trash2,
  Wind,
} from 'lucide-react';
import type {WellnessSessionLog} from '../types/bloomi';

interface ReportTabProps {
  logs: WellnessSessionLog[];
  onClearLogs: () => void;
  onGoToStudio: () => void;
}

const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;
const DAY_MS = 24 * 60 * 60 * 1000;
const WEEKDAY_LABELS = ['일', '월', '화', '수', '목', '금', '토'];

interface DailyBucket {
  key: string;
  label: string;
  dateText: string;
  count: number;
  avgBpmDelta: number;
  avgGsrDelta: number;
}

function formatDateKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function ReportTab({logs, onClearLogs, onGoToStudio}: ReportTabProps) {
  const [periodMode, setPeriodMode] = useState<'weekly' | 'all'>('weekly');

  const recent7DayLogs = useMemo(() => {
    const now = Date.now();
    return logs.filter((log) => {
      const ts = typeof log.createdAt === 'number' && Number.isFinite(log.createdAt) ? log.createdAt : 0;
      return ts > 0 && now - ts <= SEVEN_DAYS_MS;
    });
  }, [logs]);

  const weeklyBuckets = useMemo<DailyBucket[]>(() => {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const buckets: DailyBucket[] = [];

    for (let offset = 6; offset >= 0; offset -= 1) {
      const dayStart = todayStart - offset * DAY_MS;
      const dayEnd = dayStart + DAY_MS;
      const d = new Date(dayStart);
      const dayLogs = recent7DayLogs.filter(
        (log) => log.createdAt >= dayStart && log.createdAt < dayEnd,
      );

      const count = dayLogs.length;
      const avgBpmDelta =
        count > 0
          ? Math.round(
              dayLogs.reduce((acc, item) => acc + (item.bpmAfter - item.bpmBefore), 0) / count,
            )
          : 0;
      const avgGsrDelta =
        count > 0
          ? Math.round(
              dayLogs.reduce((acc, item) => acc + (item.gsrAfter - item.gsrBefore), 0) / count,
            )
          : 0;

      buckets.push({
        key: formatDateKey(d),
        label: WEEKDAY_LABELS[d.getDay()],
        dateText: `${d.getMonth() + 1}/${d.getDate()}`,
        count,
        avgBpmDelta,
        avgGsrDelta,
      });
    }

    return buckets;
  }, [recent7DayLogs]);

  const activeLogs = periodMode === 'weekly' ? recent7DayLogs : logs;

  const summary = useMemo(() => {
    const total = activeLogs.length;
    if (total === 0) {
      return {
        total: 0,
        avgBpmChange: 0,
        avgGsrChange: 0,
        calmCount: 0,
      };
    }

    const bpmSum = activeLogs.reduce((acc, item) => acc + (item.bpmAfter - item.bpmBefore), 0);
    const gsrSum = activeLogs.reduce((acc, item) => acc + (item.gsrAfter - item.gsrBefore), 0);
    const calmCount = activeLogs.filter(
      (item) => item.mood.includes('차분') || item.mood.includes('맑아') || item.mood.includes('완화'),
    ).length;

    return {
      total,
      avgBpmChange: Math.round(bpmSum / total),
      avgGsrChange: Math.round(gsrSum / total),
      calmCount,
    };
  }, [activeLogs]);

  const maxWeeklyCount = useMemo(
    () => Math.max(1, ...weeklyBuckets.map((b) => b.count)),
    [weeklyBuckets],
  );

  return (
    <section className="space-y-6">
      {/* Header & Period Switch */}
      <div className="glass-card rounded-3xl p-5 sm:p-6 shadow-soft flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-blush-light text-blush-dark flex items-center justify-center shrink-0">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-bold text-base sm:text-lg text-charcoal">
              BLOOMI 호흡 전후 변화 &amp; 웰니스 리포트
            </h1>
            <p className="text-xs text-stone-500 mt-0.5">
              호흡 시작 직전과 종료 후 생체신호 변화 및 주관적 마음 기록을 확인합니다.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div className="inline-flex rounded-2xl bg-stone-100 p-1">
            <button
              type="button"
              onClick={() => setPeriodMode('weekly')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                periodMode === 'weekly'
                  ? 'bg-white text-charcoal shadow-xs'
                  : 'text-stone-500 hover:text-charcoal'
              }`}
            >
              최근 7일
            </button>
            <button
              type="button"
              onClick={() => setPeriodMode('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                periodMode === 'all'
                  ? 'bg-white text-charcoal shadow-xs'
                  : 'text-stone-500 hover:text-charcoal'
              }`}
            >
              전체 기록
            </button>
          </div>

          {logs.length > 0 && (
            <button
              type="button"
              onClick={onClearLogs}
              className="px-3 py-2 rounded-xl text-xs font-semibold bg-stone-100 hover:bg-rose-50 text-stone-600 hover:text-rose-600 flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>기록 초기화</span>
            </button>
          )}
        </div>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="glass-card rounded-3xl p-5 shadow-soft">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>{periodMode === 'weekly' ? '최근 7일 완료 세션' : '누적 완료 세션'}</span>
            <Wind className="w-4 h-4 text-blush-dark" />
          </div>
          <p className="text-2xl font-bold text-charcoal mt-2 tabular-nums">{summary.total}회</p>
          <p className="text-[11px] text-stone-400 mt-1">
            긍정 반응 기록 {summary.calmCount}회
          </p>
        </div>

        <div className="glass-card rounded-3xl p-5 shadow-soft">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>평균 심박수(BPM) 변화</span>
            <HeartPulse className="w-4 h-4 text-rose-500" />
          </div>
          <p className="text-2xl font-bold text-charcoal mt-2 tabular-nums">
            {summary.total > 0
              ? `${summary.avgBpmChange > 0 ? '+' : ''}${summary.avgBpmChange} BPM`
              : '-'}
          </p>
          <p className="text-[11px] text-stone-400 mt-1">
            음수(-)일수록 호흡 후 심박 안정
          </p>
        </div>

        <div className="glass-card rounded-3xl p-5 shadow-soft">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>평균 GSR 긴장도 변화</span>
            <Activity className="w-4 h-4 text-lavender-dark" />
          </div>
          <p className="text-2xl font-bold text-charcoal mt-2 tabular-nums">
            {summary.total > 0
              ? `${summary.avgGsrChange > 0 ? '+' : ''}${summary.avgGsrChange}`
              : '-'}
          </p>
          <p className="text-[11px] text-stone-400 mt-1">
            0~100 스케일 기준 세션 전후 평균 차이
          </p>
        </div>
      </div>

      {/* Recent 7-Day Weekly Bar Chart */}
      <div className="glass-card rounded-3xl p-5 sm:p-6 shadow-soft space-y-4">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <h2 className="font-bold text-sm sm:text-base text-charcoal flex items-center gap-2">
            <CalendarDays className="w-4 h-4 text-sage-dark" />
            최근 7일 요일별 호흡 세션 집계
          </h2>
          <span className="text-xs text-stone-400 tabular-nums">
            7일간 총 {recent7DayLogs.length}회 세션
          </span>
        </div>

        <div className="grid grid-cols-7 gap-2 sm:gap-4 items-end pt-4 pb-1">
          {weeklyBuckets.map((bucket) => {
            const heightPercent =
              bucket.count === 0 ? 6 : Math.max(18, Math.round((bucket.count / maxWeeklyCount) * 100));
            return (
              <div key={bucket.key} className="flex flex-col items-center gap-2">
                <span className="text-[11px] font-bold text-charcoal tabular-nums">
                  {bucket.count}회
                </span>
                <div className="w-full h-32 bg-stone-100/90 rounded-2xl flex items-end p-1 overflow-hidden">
                  <div
                    className={`w-full rounded-xl transition-all duration-500 ${
                      bucket.count > 0 ? 'bg-blush' : 'bg-stone-200'
                    }`}
                    style={{height: `${heightPercent}%`}}
                    title={`${bucket.dateText} (${bucket.label}): ${bucket.count}회`}
                  />
                </div>
                <div className="text-center">
                  <p className="text-xs font-bold text-charcoal">{bucket.label}</p>
                  <p className="text-[10px] text-stone-400 tabular-nums">{bucket.dateText}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Session History List */}
      <div className="glass-card rounded-3xl p-5 sm:p-6 shadow-soft space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-sm sm:text-base text-charcoal flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blush-dark" />
            호흡 전후 세션 기록 ({activeLogs.length}건)
          </h2>
        </div>

        {activeLogs.length === 0 ? (
          <div className="text-center py-10 space-y-3">
            <p className="text-sm font-semibold text-stone-600">
              아직 표시할 호흡 기록이 없습니다.
            </p>
            <p className="text-xs text-stone-400">
              스튜디오에서 호흡을 진행한 뒤 마음 상태를 기록하면 전후 변화가 이곳에 쌓입니다.
            </p>
            <button
              type="button"
              onClick={onGoToStudio}
              className="px-4 py-2 rounded-xl bg-charcoal hover:bg-stone-800 text-white text-xs font-semibold transition-all cursor-pointer"
            >
              스튜디오로 이동하기
            </button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {activeLogs.map((log) => {
              const bpmDiff = log.bpmAfter - log.bpmBefore;
              const gsrDiff = log.gsrAfter - log.gsrBefore;
              return (
                <div
                  key={log.id}
                  className="p-3.5 sm:p-4 rounded-2xl bg-white/85 border border-stone-200/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-charcoal">{log.routine}</span>
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-blush-light text-blush-dark font-semibold">
                        {log.mood}
                      </span>
                      <span className="text-[11px] text-stone-400">{log.time}</span>
                    </div>
                    <p className="text-xs text-stone-600 tabular-nums">
                      BPM: <strong>{log.bpmBefore}</strong> → <strong>{log.bpmAfter}</strong> (
                      <span className={bpmDiff <= 0 ? 'text-emerald-600 font-semibold' : 'text-rose-600 font-semibold'}>
                        {bpmDiff > 0 ? `+${bpmDiff}` : bpmDiff}
                      </span>
                      ) · GSR: <strong>{log.gsrBefore}</strong> → <strong>{log.gsrAfter}</strong> (
                      <span className={gsrDiff <= 0 ? 'text-emerald-600 font-semibold' : 'text-rose-600 font-semibold'}>
                        {gsrDiff > 0 ? `+${gsrDiff}` : gsrDiff}
                      </span>
                      )
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}